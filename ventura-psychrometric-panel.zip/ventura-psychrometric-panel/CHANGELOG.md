# Changelog

## 1.0.0

Initial release with base features.

- Visualization of one data series of psychrometric properties with various field options
- A robust chart editor with graph options and display options
- Interactivity via hovering over data points or parts of the graph with the mouse